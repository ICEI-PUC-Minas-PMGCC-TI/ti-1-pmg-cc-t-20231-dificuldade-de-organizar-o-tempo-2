let dados = JSON.parse(localStorage.getItem('Cadastrados'));


let email = document.querySelector("#email");
let senha = document.querySelector("#senha");
function submit() {
  if(email.value != "" && senha.value != ""){
    dados.forEach(x => {
        if(x.email == email.value && x.senha == senha.value){
            localStorage.setItem('acesso','liberado');
            console.log('Liberado');
            window.open('/index.html','_self');
            return;
        }
      localStorage.setItem('acesso','negado');
    })
  }else{
    email.placeholder = 'Preencha este campo';
    senha.placeholder = 'Preencha este campo';
  }
}