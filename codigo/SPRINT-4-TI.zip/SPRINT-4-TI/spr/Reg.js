var registro = JSON.parse(localStorage.getItem('Cadastrados'));
if(registro == null){
  registro = [];
}
    function f1(){
      /*atribui os valores dos inputs a algumas variaveis */
              let nome = document.getElementById('nome').value;
              console.log( document.getElementById('nome').value)
      
              let email = document.getElementById('email').value;
              console.log(document.getElementById('email').value)
      
              let senha = document.getElementById('senha').value;
              console.log(document.getElementById('senha').value)
      /*Nessa sintaxe que eu coloquei abaixo, diz o seguinte, nome dentro da variavel registro será igual ao valor da const nome*/
      if(nome != "" && email != "" && senha != ""){
      let dados = {
        nome:nome,
        email:email,
        senha:senha
      }
      registro.push(dados);
      localStorage.setItem('Cadastrados',JSON.stringify(registro));
      localStorage.setItem('acesso','liberado');
                  window.open('/index.html','_self');

      }else{
        document.getElementById('nome').placeholder = 'Preencha esse campo';
        document.getElementById('email').placeholder = 'Preencha esse campo';
        document.getElementById('senha').placeholder = 'Preencha esse campo';
      }
        }
      