let dadosJson = JSON.parse(localStorage.getItem('events'));
var Notification = [];
function getDados() {
  dadosJson = JSON.parse(localStorage.getItem('events'));
  Notification = [];
  dadosJson.forEach(function(data) {
    var events = data.events;
    events.forEach(function(event) {
      var horarios = event.time.split(" - ");
      horarios = event.time.split(" ");
      var horaInicio = horarios[0];

      var dataCompleta = `${data.year}-${data.month}-${data.day}`;

      var notificacao = {
        titulo: event.title,
        horario: horaInicio,
        data: dataCompleta
      };

      Notification.push(notificacao);
    });
  });
}
getDados();
window.addEventListener('storage', function() {
  window.location.reload();
})
// criar as tags da barra de animação
function removerBarra() {
  document.querySelectorAll(".body").forEach(x => {
    x.remove();
  });
}

function criarBarra() {
  const NOTIFICATIONBAR = document.createElement('header');
  NOTIFICATIONBAR.classList.add('notificationBar');

  document.querySelector("body").insertBefore(NOTIFICATIONBAR, document.querySelector("body").firstChild);

  const NOTIFICATIONICON = document.createElement('div');
  NOTIFICATIONICON.classList.add('notificationIcon');
  NOTIFICATIONBAR.appendChild(NOTIFICATIONICON);

  const imageICONS = document.createElement('img');
  imageICONS.classList.add('notificar');
  imageICONS.setAttribute('width', '40px');
  imageICONS.setAttribute('height', '40px');
  imageICONS.src = 'bell.png';
  NOTIFICATIONICON.appendChild(imageICONS);

  const FECHAR = document.createElement('div');
  FECHAR.classList.add('fecharNoti');
  NOTIFICATIONBAR.appendChild(FECHAR);

  const imageFECHAR = document.createElement('img');
  imageFECHAR.setAttribute('width', '15');
  imageFECHAR.src = 'close.png';
  FECHAR.appendChild(imageFECHAR);

  const NumeroDeNotificacoes = document.createElement('div');
  NumeroDeNotificacoes.classList.add('numerosDeNotificacao');
  NOTIFICATIONBAR.appendChild(NumeroDeNotificacoes);
}

criarBarra();

// chamar a função a cada 5s para testar a hora e data
var testarDATA = setInterval(GethourNow, 2000);

function pegarDataDeAgora() {
  let diaHJ = new Date().getDate();

  let mesNow = new Date().getMonth() + 1;

  let anoNow = new Date().getFullYear();
  let dataCompleta = `${anoNow}-${mesNow}-${diaHJ}`;
  return dataCompleta;
}

function GethourNow() {
  if (Notification.length == 0) {
    clearInterval(testarDATA);
    return 0;
  }

  let data = new Date();
  let horaNow = data.getHours();
  if (12 < horaNow && horaNow <= 23) {
    horaNow -= 12;
  }
  if (0 == horaNow) {
    horaNow = 12;
  }

  let minutos = data.getMinutes();
  if (Number(minutos) < 10) {
    minutos = '0' + minutos;
  }
  let horasCompleta = `${horaNow}:${minutos}`;

  let dataCompleta = pegarDataDeAgora();
  Notification = Notification.filter(a => a.horario >= horasCompleta && a.data >= dataCompleta);
  let novaNot = Notification.filter((a) => a.horario == horasCompleta && a.data == dataCompleta);
  if (novaNot.length > 0) {
    novaNot.forEach((x) => {
      notification(x);
      let p = Notification.indexOf(x);
      Notification = Notification.filter(a => a != x);
      localStorage.setItem('events', JSON.stringify(Notification));
    });
  }
  console.log(`${horasCompleta} -------- ${dataCompleta}`);
}

// animação do sino da notificação
const sino = document.querySelector(".notificar");
sino.addEventListener('click', () => {
  const quantidadeNotes = document.querySelector(".numerosDeNotificacao");
  quantidadeNotes.textContent = '';
  quantidadeNotes.style.display = 'none';
  if (sino.classList.contains('notificarOpen')) {
    sino.classList.remove('notificarOpen');
    document.querySelectorAll(".body").forEach(ele => {
      if (ele.classList.contains('TirarNotificar')) {
        ele.classList.remove('TirarNotificar');
        ele.classList.add('abrirNotificar');
      } else {
        ele.classList.remove('abrirNotificar');
        ele.classList.add('TirarNotificar');
      }
    });
  } else {
    sino.classList.add('notificarOpen');
    document.querySelectorAll(".body").forEach(ele => {
      if (ele.classList.contains('TirarNotificar')) {
        ele.classList.remove('TirarNotificar');
        ele.classList.add('abrirNotificar');
      } else {
        ele.classList.remove('abrirNotificar');
        ele.classList.add('TirarNotificar');
      }
    });
  }
});

// animação da notificação saindo
document.querySelector(".fecharNoti").addEventListener('click', () => {
  document.querySelector(".notificationBar").classList.remove('DescerNotificar');
  document.querySelector(".notificationBar").classList.add('chamarAnimacao');
  setTimeout(voltarOriginal, 5000);
});

function voltarOriginal() {
  document.querySelector(".notificationBar").classList.remove('chamarAnimacao');
  document.querySelector(".notificar").classList.remove('notificarOpen');
  removerBarra();
}

function notification(x) {
  const header = document.createElement('div');
  header.classList.add('body');
  if (sino.classList.contains('notificarOpen')) {
    header.classList.add('abrirNotificar');
  } else {
    header.classList.add('TirarNotificar');
  }

  const titulo = document.createElement('h1');
  titulo.classList.add('title_');
  titulo.textContent = 'Lembrete de Tarefa';
  header.appendChild(titulo);

  const horaAgora = document.createElement('p');
  horaAgora.classList.add('horarioAgora');
  const txt = `<strong>${x.horario}</strong>`;
  horaAgora.innerHTML = txt;
  header.appendChild(horaAgora);

  const conteudo = document.createElement('p');
  conteudo.textContent = x.titulo;
  conteudo.classList.add('conteudo');
  header.appendChild(conteudo);

  let corpoDaNotificar = document.querySelector(".notificationBar");
  let segundo = corpoDaNotificar.children[1];
  corpoDaNotificar.insertBefore(header, segundo);
  document.querySelector("header.notificationBar").classList.add('DescerNotificar');

  const quantidadeNotes = document.querySelector(".numerosDeNotificacao");
  quantidadeNotes.style.display = 'flex';
  quantidadeNotes.textContent = document.querySelectorAll(".body").length;
}



