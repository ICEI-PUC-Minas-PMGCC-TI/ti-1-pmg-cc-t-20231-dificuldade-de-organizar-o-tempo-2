document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('ifoodButton').addEventListener('click', function() {
      resgatarGiftCard('iFood');
    });
  
    document.getElementById('spotifyButton').addEventListener('click', function() {
      resgatarGiftCard('Spotify');
    });
  
    document.getElementById('netflixButton').addEventListener('click', function() {
      resgatarGiftCard('Netflix');
    });
  
    document.getElementById('uberButton').addEventListener('click', function() {
      resgatarGiftCard('Uber');
    });
  
    document.getElementById('steamButton').addEventListener('click', function() {
      resgatarGiftCard('Steam');
    });
  
    document.getElementById('xboxButton').addEventListener('click', function() {
      resgatarGiftCard('Xbox Live Gold');
    });
  
    function resgatarGiftCard(giftCard) {
      const tempoApoioMinimo = {
        iFood: 2,
        Spotify: 4,
        Netflix: 10,
        Uber: 6,
        Steam: 6,
        'Xbox Live Gold': 8
      };
  
      const tempoApoio = 6; //
  
      let mensagem;
  
      if (tempoApoio >= tempoApoioMinimo[giftCard]) {
        mensagem = 'Gift Card ' + giftCard + ' resgatado e será enviado por e-mail!';
      } else {
        mensagem = 'Você precisa apoiar o site por pelo menos ' + tempoApoioMinimo[giftCard] + ' meses para resgatar o Gift Card ' + giftCard + '.';
      }
  
      alert(mensagem);
    }
  });
  