let dadosJson = JSON.parse(localStorage.getItem('events'));

f1();

function f1(){
  
  dadosJson.forEach(x => {
    const div = document.getElementById('compromissos');
    
    const h = document.createElement('h5');
    h.classList.add('dia_');
    h.textContent = `${x.day}-${x.month}-${x.year}`
    div.appendChild(h);
    x.events.forEach(a => {
    const ul = document.createElement('ul');
    const li = document.createElement('li');
    const li01 = document.createElement('li');
    li.textContent = `Titulo: ${a.title}`;
    li01.textContent = 'Hora: ' + a.time;
    ul.classList.add('lista');
    ul.appendChild(li);
    ul.appendChild(li01);
    div.appendChild(ul);
})
});
}
